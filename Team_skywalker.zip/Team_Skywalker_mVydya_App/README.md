mVydya
It's a Pharmacy application that help you in curing basic symptoms and diseases with medicines available in your home.

How to run your code.
Clone or download the repo and place it anywhere in your computer. Open the folder in Android Studio or VS Code. Make sure that you have Android SDK already installed.
After the command is run successfully you can run the app on real device or on emulator by pressing the Play button in Android Studio or by pressing F5 in VS Code.

Doctor's Panel

A doctor can perform the following features for now:

    Add Medicine/Disease

    View Medicine/Disease

    Update Medicine/Disease

    Delete Medicine/Disease

    Update profile

Patient's Panel

A patient can perform the following features for now:

    View Medicine/Disease

    View Doctor's profile for contact

Features in Future

Following features could be added in future:

    Doctor and Patient panel's could be separted in two apps.

    Doctor can only edit or delete the medicine/disease which he/she has posted not anyone else's.

    Patient can request to add new medicine/disease.

    Chat feature between Doctor and Patient for discussion.

